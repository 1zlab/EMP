from distutils.core import setup

setup(
    name = 'eemp',      
    version = '1.1.0',
    py_modules = ['wifi','decorators'],
    author = 'fuermohao@1zlab.com',        
    author_email = 'fuermohao@outlook.com',
    url = 'http://emp.1zlab.com',
    description = 'emp is a upy module to make things Easy on MicroPython.'   
    )